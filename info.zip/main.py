from gui.gui import SudokuGUI

def main():
    gui = SudokuGUI()
    gui.run()

if __name__ == "__main__":
    main()
